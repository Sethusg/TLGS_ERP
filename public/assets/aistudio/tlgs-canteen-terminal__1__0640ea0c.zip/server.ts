import express from 'express';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import path from 'path';

const app = express();
app.use(express.json());

const DATA_DIR = path.resolve(process.cwd(), 'data');
const THEME_FILE = path.join(DATA_DIR, 'theme-settings.json');

const DEFAULT_THEME = {
  pos_background_color: '#0B1228',
  header_background_color: '#0E172E',
  catalogue_background_color: '#0B1228',
  product_card_background_color: '#121D38',
  order_panel_background_color: '#0E172E',
  sidebar_background_color: '#0E172E',
  primary_button_color: '#F59E0B',
  text_color: '#F1F5F9',
  accent_color: '#38BDF8',
  selected_theme: 'dark',
  updated_by: 'System Administrator',
  updated_at: new Date().toISOString(),
};

function readThemeSettings() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(THEME_FILE)) {
      fs.writeFileSync(THEME_FILE, JSON.stringify(DEFAULT_THEME, null, 2), 'utf-8');
      return DEFAULT_THEME;
    }
    const raw = fs.readFileSync(THEME_FILE, 'utf-8');
    return { ...DEFAULT_THEME, ...JSON.parse(raw) };
  } catch (err) {
    console.error('Error reading theme settings file:', err);
    return DEFAULT_THEME;
  }
}

function writeThemeSettings(data: any) {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  fs.writeFileSync(THEME_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

const HEX_REGEX = /^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/;

const COLOR_FIELDS = [
  'pos_background_color',
  'header_background_color',
  'catalogue_background_color',
  'product_card_background_color',
  'order_panel_background_color',
  'sidebar_background_color',
  'primary_button_color',
  'text_color',
  'accent_color',
];

// GET /api/theme-settings - Retrieve active POS theme configuration
app.get('/api/theme-settings', (_req, res) => {
  const current = readThemeSettings();
  res.json(current);
});

// PUT /api/theme-settings - Update POS theme settings (Protected for Admin/Manager)
app.put('/api/theme-settings', (req, res) => {
  const userRole = (req.headers['x-user-role'] as string) || req.body.user_role;
  if (userRole && userRole === 'cashier') {
    return res.status(403).json({
      detail: 'Permission denied. Only authenticated administrators and managers may modify appearance settings.',
    });
  }

  // Validate HEX colors
  for (const field of COLOR_FIELDS) {
    if (req.body[field] !== undefined) {
      const val = String(req.body[field]).trim();
      if (!HEX_REGEX.test(val)) {
        return res.status(400).json({
          detail: `Invalid HEX colour code for ${field}: "${req.body[field]}". Must be a valid 3 or 6 digit hex format like #0B1228 or #FFF.`,
        });
      }
    }
  }

  const existing = readThemeSettings();
  const updated = {
    ...existing,
    ...req.body,
    updated_at: new Date().toISOString(),
    updated_by: req.body.updated_by || (req.headers['x-user-name'] as string) || 'Admin',
  };

  writeThemeSettings(updated);
  return res.json(updated);
});

// POST /api/theme-settings/reset - Reset to default Midnight Navy theme
app.post('/api/theme-settings/reset', (req, res) => {
  const userRole = (req.headers['x-user-role'] as string) || req.body.user_role;
  if (userRole && userRole === 'cashier') {
    return res.status(403).json({
      detail: 'Permission denied. Only administrators and managers may reset appearance settings.',
    });
  }

  const resetData = {
    ...DEFAULT_THEME,
    updated_at: new Date().toISOString(),
    updated_by: req.body.updated_by || 'Admin (Reset)',
  };

  writeThemeSettings(resetData);
  return res.json(resetData);
});

async function startServer() {
  // Parse command line port if provided (e.g., --port 3000)
  let port = Number(process.env.PORT) || 3000;
  const args = process.argv.slice(2);
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--port' && args[i + 1]) {
      port = Number(args[i + 1]);
    }
  }

  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(process.cwd(), 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`[POS Server] Running on http://0.0.0.0:${port}`);
  });
}

startServer();
