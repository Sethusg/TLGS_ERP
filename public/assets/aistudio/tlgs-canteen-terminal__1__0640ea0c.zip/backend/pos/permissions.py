from rest_framework.permissions import BasePermission, SAFE_METHODS
class IsStaffOrReadOnly(BasePermission):
    """Authenticated users may read; only Django staff can change master data."""
    def has_permission(self, request, view):
        if not request.user or not request.user.is_authenticated:
            return False
        return request.method in SAFE_METHODS or request.user.is_staff
