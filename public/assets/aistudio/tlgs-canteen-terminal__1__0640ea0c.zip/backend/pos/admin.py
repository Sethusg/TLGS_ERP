from django.contrib import admin
from .models import (
    Product,
    Sale,
    SaleItem,
    InventoryMovement,
    StoreSettings,
    RegisterClosing,
    PosThemeSettings,
)

@admin.register(RegisterClosing)
class RegisterClosingAdmin(admin.ModelAdmin):
    list_display = (
        "shift_session_id",
        "cashier",
        "opened_at",
        "closed_at",
        "opening_cash",
        "actual_cash",
        "expected_cash",
        "cash_difference",
        "actual_total",
        "total_difference",
        "status",
    )
    list_filter = ("status", "cashier", "closed_at")
    search_fields = ("shift_session_id", "cashier__username", "closing_notes")
    readonly_fields = (
        "shift_session_id",
        "cashier",
        "opened_at",
        "closed_at",
        "opening_cash",
        "actual_cash",
        "actual_upi",
        "actual_card",
        "actual_other",
        "actual_total",
        "expected_cash",
        "expected_upi",
        "expected_card",
        "expected_other",
        "expected_total",
        "cash_difference",
        "total_difference",
        "sales_count",
        "total_sales_amount",
    )
    def has_add_permission(self, request): return False

@admin.register(PosThemeSettings)
class PosThemeSettingsAdmin(admin.ModelAdmin):
    list_display = (
        "selected_theme",
        "pos_background_color",
        "header_background_color",
        "product_card_background_color",
        "primary_button_color",
        "updated_by",
        "updated_at",
    )
    readonly_fields = ("updated_at",)
    def has_add_permission(self, request): return not PosThemeSettings.objects.exists()
    def has_delete_permission(self, request, obj=None): return False

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("sku", "name", "category", "price", "stock_quantity", "is_active")
    search_fields = ("sku", "name", "barcode")
    list_filter = ("category", "is_active")

class SaleItemInline(admin.TabularInline):
    model = SaleItem
    extra = 0
    readonly_fields = ["product", "product_name", "sku", "quantity", "unit_price", "discount_amount", "tax_amount", "line_total"]
    can_delete = False

@admin.register(Sale)
class SaleAdmin(admin.ModelAdmin):
    list_display = ("receipt_number", "cashier", "total_amount", "payment_method", "created_at")
    list_filter = ("payment_method", "created_at")
    search_fields = ("receipt_number", "cashier__username")
    readonly_fields = ("receipt_number", "idempotency_key", "cashier", "subtotal", "discount_amount", "tax_amount", "total_amount", "payment_method", "amount_tendered", "change_due", "created_at")
    inlines = [SaleItemInline]
    def has_add_permission(self, request): return False
    def has_delete_permission(self, request, obj=None): return False

@admin.register(InventoryMovement)
class InventoryMovementAdmin(admin.ModelAdmin):
    list_display = ("product", "change_quantity", "reason", "user", "created_at")
    list_filter = ("created_at",)
    search_fields = ("product__name", "reason", "reference")
    readonly_fields = ("product", "user", "change_quantity", "reason", "reference", "created_at")
    def has_add_permission(self, request): return False
    def has_change_permission(self, request, obj=None): return False
    def has_delete_permission(self, request, obj=None): return False

@admin.register(StoreSettings)
class StoreSettingsAdmin(admin.ModelAdmin):
    def has_add_permission(self, request): return not StoreSettings.objects.exists()
