import uuid
from decimal import Decimal
from django.conf import settings
from django.db import models
from django.utils import timezone

class Product(models.Model):
    sku = models.CharField(max_length=64, unique=True)
    barcode = models.CharField(max_length=128, blank=True, db_index=True)
    name = models.CharField(max_length=180, db_index=True)
    category = models.CharField(max_length=100, default="General", db_index=True)
    price = models.DecimalField(max_digits=12, decimal_places=2)
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("0.00"))
    stock_quantity = models.PositiveIntegerField(default=0)
    reorder_level = models.PositiveIntegerField(default=5)
    is_active = models.BooleanField(default=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        ordering = ["name"]
        constraints = [
            models.CheckConstraint(condition=models.Q(price__gte=0), name="product_price_nonnegative"),
            models.CheckConstraint(condition=models.Q(tax_rate__gte=0) & models.Q(tax_rate__lte=100), name="product_tax_range"),
        ]
    def __str__(self):
        return f"{self.sku} — {self.name}"

class RegisterClosing(models.Model):
    shift_session_id = models.CharField(max_length=64, unique=True, db_index=True)
    cashier = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="register_closings")
    opened_at = models.DateTimeField(db_index=True)
    closed_at = models.DateTimeField(default=timezone.now, db_index=True)
    opening_cash = models.DecimalField(max_digits=12, decimal_places=2)
    actual_cash = models.DecimalField(max_digits=12, decimal_places=2)
    actual_upi = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    actual_card = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    actual_other = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    actual_total = models.DecimalField(max_digits=12, decimal_places=2)
    expected_cash = models.DecimalField(max_digits=12, decimal_places=2)
    expected_upi = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    expected_card = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    expected_other = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    expected_total = models.DecimalField(max_digits=12, decimal_places=2)
    cash_difference = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    total_difference = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    sales_count = models.PositiveIntegerField(default=0)
    total_sales_amount = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    closing_notes = models.TextField(blank=True)
    status = models.CharField(max_length=20, default="closed", choices=[("closed", "Closed"), ("verified", "Verified by Manager")])

    class Meta:
        ordering = ["-closed_at"]
        verbose_name = "Register Closing"
        verbose_name_plural = "Register Closings"

    def __str__(self):
        return f"{self.shift_session_id} — {self.cashier} ({self.closed_at:%Y-%m-%d %H:%M})"

class Sale(models.Model):
    PAYMENT_CHOICES = [("cash", "Cash"), ("card", "Card"), ("upi", "UPI"), ("other", "Other")]
    receipt_number = models.CharField(max_length=40, unique=True, editable=False)
    idempotency_key = models.UUIDField(null=True, blank=True, unique=True, editable=False)
    cashier = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="pos_sales")
    register_closing = models.ForeignKey(RegisterClosing, on_delete=models.SET_NULL, null=True, blank=True, related_name="sales")
    subtotal = models.DecimalField(max_digits=12, decimal_places=2)
    discount_amount = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    tax_amount = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    total_amount = models.DecimalField(max_digits=12, decimal_places=2)
    payment_method = models.CharField(max_length=12, choices=PAYMENT_CHOICES)
    amount_tendered = models.DecimalField(max_digits=12, decimal_places=2)
    change_due = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    created_at = models.DateTimeField(default=timezone.now, db_index=True)
    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["created_at", "payment_method"], name="sale_created_payment_idx")]
    def save(self, *args, **kwargs):
        if not self.receipt_number:
            self.receipt_number = f"POS-{timezone.localdate():%Y%m%d}-{uuid.uuid4().hex[:8].upper()}"
        super().save(*args, **kwargs)
    def __str__(self):
        return self.receipt_number

class SaleItem(models.Model):
    sale = models.ForeignKey(Sale, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.PROTECT, related_name="sale_items")
    product_name = models.CharField(max_length=180)
    sku = models.CharField(max_length=64)
    quantity = models.PositiveIntegerField()
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    discount_amount = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    tax_amount = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    line_total = models.DecimalField(max_digits=12, decimal_places=2)
    class Meta:
        ordering = ["id"]

class InventoryMovement(models.Model):
    product = models.ForeignKey(Product, on_delete=models.PROTECT, related_name="inventory_movements")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    change_quantity = models.IntegerField()
    reason = models.CharField(max_length=240)
    reference = models.CharField(max_length=80, blank=True)
    created_at = models.DateTimeField(default=timezone.now, db_index=True)
    class Meta:
        ordering = ["-created_at"]

class StoreSettings(models.Model):
    """One-row settings record for a single store in this starter."""
    store_name = models.CharField(max_length=160, default="My Store")
    address = models.CharField(max_length=240, blank=True)
    phone = models.CharField(max_length=40, blank=True)
    tax_number = models.CharField(max_length=80, blank=True)
    receipt_footer = models.CharField(max_length=240, default="Thank you. Please visit again!")
    currency_code = models.CharField(max_length=3, default="INR")
    updated_at = models.DateTimeField(auto_now=True)
    def save(self, *args, **kwargs):
        self.pk = 1
        super().save(*args, **kwargs)
    @classmethod
    def get_settings(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj

class PosThemeSettings(models.Model):
    """
    Persistent store configuration for dynamic POS background and UI appearance.
    Enforces a single store configuration row (pk=1) to prevent duplicate records.
    """
    THEME_CHOICES = [
        ("dark", "Midnight Navy (Dark)"),
        ("deep_blue", "Deep Blue"),
        ("light", "Light Professional"),
        ("forest_green", "Forest Green"),
        ("custom", "Custom Theme"),
    ]
    pos_background_color = models.CharField(max_length=7, default="#0B1228")
    header_background_color = models.CharField(max_length=7, default="#0E172E")
    catalogue_background_color = models.CharField(max_length=7, default="#0B1228")
    product_card_background_color = models.CharField(max_length=7, default="#121D38")
    order_panel_background_color = models.CharField(max_length=7, default="#0E172E")
    sidebar_background_color = models.CharField(max_length=7, default="#0E172E")
    primary_button_color = models.CharField(max_length=7, default="#F59E0B")
    text_color = models.CharField(max_length=7, default="#F1F5F9")
    accent_color = models.CharField(max_length=7, default="#38BDF8")
    selected_theme = models.CharField(max_length=32, default="dark", choices=THEME_CHOICES)
    updated_by = models.CharField(max_length=150, blank=True, default="Admin")
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "POS Theme Settings"
        verbose_name_plural = "POS Theme Settings"

    def save(self, *args, **kwargs):
        self.pk = 1
        super().save(*args, **kwargs)

    @classmethod
    def get_settings(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj

    def __str__(self):
        return f"POS Theme Settings ({self.selected_theme}) — Last updated by {self.updated_by}"
