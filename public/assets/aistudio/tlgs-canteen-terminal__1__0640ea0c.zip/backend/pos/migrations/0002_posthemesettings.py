from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [
        ("pos", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="PosThemeSettings",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("pos_background_color", models.CharField(default="#0B1228", max_length=7)),
                ("header_background_color", models.CharField(default="#0E172E", max_length=7)),
                ("catalogue_background_color", models.CharField(default="#0B1228", max_length=7)),
                ("product_card_background_color", models.CharField(default="#121D38", max_length=7)),
                ("order_panel_background_color", models.CharField(default="#0E172E", max_length=7)),
                ("sidebar_background_color", models.CharField(default="#0E172E", max_length=7)),
                ("primary_button_color", models.CharField(default="#F59E0B", max_length=7)),
                ("text_color", models.CharField(default="#F1F5F9", max_length=7)),
                ("accent_color", models.CharField(default="#38BDF8", max_length=7)),
                (
                    "selected_theme",
                    models.CharField(
                        choices=[
                            ("dark", "Midnight Navy (Dark)"),
                            ("deep_blue", "Deep Blue"),
                            ("light", "Light Professional"),
                            ("forest_green", "Forest Green"),
                            ("custom", "Custom Theme"),
                        ],
                        default="dark",
                        max_length=32,
                    ),
                ),
                ("updated_by", models.CharField(blank=True, default="Admin", max_length=150)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={
                "verbose_name": "POS Theme Settings",
                "verbose_name_plural": "POS Theme Settings",
            },
        ),
    ]
