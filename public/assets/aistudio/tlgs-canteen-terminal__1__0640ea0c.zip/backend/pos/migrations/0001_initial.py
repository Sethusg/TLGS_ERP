import decimal
import django.db.models.deletion
import django.utils.timezone
from django.conf import settings
from django.db import migrations, models

class Migration(migrations.Migration):
    initial = True
    dependencies = [migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations = [
        migrations.CreateModel(name="Product", fields=[
            ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
            ("sku", models.CharField(max_length=64, unique=True)),
            ("barcode", models.CharField(blank=True, db_index=True, max_length=128)),
            ("name", models.CharField(db_index=True, max_length=180)),
            ("category", models.CharField(db_index=True, default="General", max_length=100)),
            ("price", models.DecimalField(decimal_places=2, max_digits=12)),
            ("tax_rate", models.DecimalField(decimal_places=2, default=decimal.Decimal("0.00"), max_digits=5)),
            ("stock_quantity", models.PositiveIntegerField(default=0)),
            ("reorder_level", models.PositiveIntegerField(default=5)),
            ("is_active", models.BooleanField(db_index=True, default=True)),
            ("created_at", models.DateTimeField(auto_now_add=True)),
            ("updated_at", models.DateTimeField(auto_now=True)),
        ], options={"ordering": ["name"], "constraints": [
            models.CheckConstraint(condition=models.Q(price__gte=0), name="product_price_nonnegative"),
            models.CheckConstraint(condition=models.Q(tax_rate__gte=0) & models.Q(tax_rate__lte=100), name="product_tax_range"),
        ]}),
        migrations.CreateModel(name="StoreSettings", fields=[
            ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
            ("store_name", models.CharField(default="My Store", max_length=160)),
            ("address", models.CharField(blank=True, max_length=240)),
            ("phone", models.CharField(blank=True, max_length=40)),
            ("tax_number", models.CharField(blank=True, max_length=80)),
            ("receipt_footer", models.CharField(default="Thank you. Please visit again!", max_length=240)),
            ("currency_code", models.CharField(default="INR", max_length=3)),
            ("updated_at", models.DateTimeField(auto_now=True)),
        ]),
        migrations.CreateModel(name="Sale", fields=[
            ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
            ("receipt_number", models.CharField(editable=False, max_length=40, unique=True)),
            ("idempotency_key", models.UUIDField(blank=True, editable=False, null=True, unique=True)),
            ("subtotal", models.DecimalField(decimal_places=2, max_digits=12)),
            ("discount_amount", models.DecimalField(decimal_places=2, default=decimal.Decimal("0.00"), max_digits=12)),
            ("tax_amount", models.DecimalField(decimal_places=2, default=decimal.Decimal("0.00"), max_digits=12)),
            ("total_amount", models.DecimalField(decimal_places=2, max_digits=12)),
            ("payment_method", models.CharField(choices=[("cash", "Cash"), ("card", "Card"), ("upi", "UPI"), ("other", "Other")], max_length=12)),
            ("amount_tendered", models.DecimalField(decimal_places=2, max_digits=12)),
            ("change_due", models.DecimalField(decimal_places=2, default=decimal.Decimal("0.00"), max_digits=12)),
            ("created_at", models.DateTimeField(db_index=True, default=django.utils.timezone.now)),
            ("cashier", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="pos_sales", to=settings.AUTH_USER_MODEL)),
        ], options={"ordering": ["-created_at"], "indexes": [models.Index(fields=["created_at", "payment_method"], name="sale_created_payment_idx")]}),
        migrations.CreateModel(name="InventoryMovement", fields=[
            ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
            ("change_quantity", models.IntegerField()), ("reason", models.CharField(max_length=240)),
            ("reference", models.CharField(blank=True, max_length=80)),
            ("created_at", models.DateTimeField(db_index=True, default=django.utils.timezone.now)),
            ("product", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="inventory_movements", to="pos.product")),
            ("user", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to=settings.AUTH_USER_MODEL)),
        ], options={"ordering": ["-created_at"]}),
        migrations.CreateModel(name="SaleItem", fields=[
            ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
            ("product_name", models.CharField(max_length=180)), ("sku", models.CharField(max_length=64)),
            ("quantity", models.PositiveIntegerField()), ("unit_price", models.DecimalField(decimal_places=2, max_digits=12)),
            ("discount_amount", models.DecimalField(decimal_places=2, default=decimal.Decimal("0.00"), max_digits=12)),
            ("tax_amount", models.DecimalField(decimal_places=2, default=decimal.Decimal("0.00"), max_digits=12)),
            ("line_total", models.DecimalField(decimal_places=2, max_digits=12)),
            ("product", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="sale_items", to="pos.product")),
            ("sale", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="items", to="pos.sale")),
        ], options={"ordering": ["id"]}),
    ]
