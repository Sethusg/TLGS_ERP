from django.core.management.base import BaseCommand
from django.db import connection
from pos.models import Product, StoreSettings
class Command(BaseCommand):
    help = "Smoke-check database connectivity and POS setup."
    def handle(self, *args, **options):
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
        StoreSettings.get_settings()
        self.stdout.write(self.style.SUCCESS(f"Database OK; {Product.objects.count()} product(s) available."))
