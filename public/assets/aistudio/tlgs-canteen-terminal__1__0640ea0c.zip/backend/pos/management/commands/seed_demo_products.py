from decimal import Decimal
from django.core.management.base import BaseCommand
from pos.models import Product
SAMPLE = [
    ("FOOD-001", "Classic Burger", "Food", "129.00", "5.00", 25),
    ("FOOD-002", "Veg Sandwich", "Food", "89.00", "5.00", 20),
    ("DRINK-001", "Fresh Lime Soda", "Beverages", "65.00", "5.00", 30),
    ("DRINK-002", "Mineral Water 1L", "Beverages", "25.00", "0.00", 40),
    ("FOOD-003", "French Fries", "Food", "79.00", "5.00", 18),
    ("FOOD-004", "Chicken Wrap", "Food", "149.00", "5.00", 15),
    ("DESS-001", "Chocolate Brownie", "Desserts", "99.00", "5.00", 12),
    ("DRINK-003", "Filter Coffee", "Beverages", "35.00", "5.00", 35),
    ("GROC-001", "Paper Carry Bag", "Accessories", "5.00", "0.00", 100),
]
class Command(BaseCommand):
    help = "Create example POS products without overwriting existing records."
    def handle(self, *args, **options):
        created = 0
        for sku, name, category, price, tax, stock in SAMPLE:
            _, was_created = Product.objects.get_or_create(sku=sku, defaults={"name": name, "category": category, "price": Decimal(price), "tax_rate": Decimal(tax), "stock_quantity": stock, "reorder_level": 5})
            created += int(was_created)
        self.stdout.write(self.style.SUCCESS(f"Demo products ready. Newly created: {created}; total products: {Product.objects.count()}."))
