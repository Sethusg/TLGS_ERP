from decimal import Decimal
from django.contrib.auth import get_user_model
from django.test import TestCase
from rest_framework.test import APIClient
from .models import Product, Sale, InventoryMovement
User = get_user_model()

class PosApiTests(TestCase):
    def setUp(self):
        self.cashier = User.objects.create_user(username="cashier1", password="StrongTestPass!2026")
        self.manager = User.objects.create_user(username="manager1", password="StrongTestPass!2026", is_staff=True)
        self.product = Product.objects.create(sku="TEST-01", name="Test Item", category="Test", price=Decimal("100.00"), tax_rate=Decimal("5.00"), stock_quantity=5)
        self.client = APIClient()
        self.client.force_authenticate(user=self.cashier)

    def test_checkout_computes_totals_and_decrements_stock(self):
        response = self.client.post("/api/sales/checkout/", {"items":[{"product_id":self.product.id,"quantity":2}],"payment_method":"cash","discount_percent":"0","amount_tendered":"250.00"}, format="json", HTTP_IDEMPOTENCY_KEY="97d83730-8020-466d-8b29-66a6138e2c9c")
        self.assertEqual(response.status_code, 201, response.data)
        self.assertEqual(response.data["subtotal"], "200.00")
        self.assertEqual(response.data["tax_amount"], "10.00")
        self.assertEqual(response.data["total_amount"], "210.00")
        self.product.refresh_from_db()
        self.assertEqual(self.product.stock_quantity, 3)
        self.assertEqual(InventoryMovement.objects.filter(reason="Sale").count(), 1)

    def test_checkout_rejects_overselling(self):
        response = self.client.post("/api/sales/checkout/", {"items":[{"product_id":self.product.id,"quantity":99}],"payment_method":"cash","amount_tendered":"99999.00"}, format="json")
        self.assertEqual(response.status_code, 409)
        self.assertEqual(Sale.objects.count(), 0)

    def test_cash_payment_requires_enough_tendered(self):
        response = self.client.post("/api/sales/checkout/", {"items":[{"product_id":self.product.id,"quantity":1}],"payment_method":"cash","amount_tendered":"10.00"}, format="json")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(Sale.objects.count(), 0)

    def test_cashier_cannot_create_product(self):
        response = self.client.post("/api/products/", {"sku":"DENIED-1","name":"Nope","category":"Test","price":"1.00","tax_rate":"0","initial_stock":1}, format="json")
        self.assertEqual(response.status_code, 403)

    def test_duplicate_idempotency_key_does_not_double_decrement_stock(self):
        headers={"HTTP_IDEMPOTENCY_KEY":"bfb7f9cb-b5d1-455a-a2e2-ea3fa2a5fc8b"}
        payload={"items":[{"product_id":self.product.id,"quantity":1}],"payment_method":"cash","amount_tendered":"105.00"}
        first=self.client.post("/api/sales/checkout/",payload,format="json",**headers)
        second=self.client.post("/api/sales/checkout/",payload,format="json",**headers)
        self.assertEqual(first.status_code,201)
        self.assertEqual(second.status_code,200)
        self.assertEqual(Sale.objects.count(),1)
        self.product.refresh_from_db()
        self.assertEqual(self.product.stock_quantity,4)
