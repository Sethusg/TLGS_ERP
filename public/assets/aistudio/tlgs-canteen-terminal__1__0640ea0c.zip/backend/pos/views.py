from decimal import Decimal, ROUND_HALF_UP
from uuid import UUID
from django.db import transaction, IntegrityError
from django.db.models import Sum, Count, F
from django.utils import timezone
from rest_framework import viewsets, generics, status
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Product, Sale, SaleItem, InventoryMovement, StoreSettings, PosThemeSettings
from .serializers import (
    ProductSerializer,
    SaleSerializer,
    CheckoutInputSerializer,
    InventoryAdjustmentSerializer,
    StoreSettingsSerializer,
    PosThemeSettingsSerializer,
)
from .permissions import IsStaffOrReadOnly

CENT = Decimal("0.01")
def money(value):
    return Decimal(value).quantize(CENT, rounding=ROUND_HALF_UP)

class CurrentUserView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        return Response({"id": request.user.id, "username": request.user.get_username(), "is_staff": request.user.is_staff, "is_superuser": request.user.is_superuser})

class ProductViewSet(viewsets.ModelViewSet):
    serializer_class = ProductSerializer
    permission_classes = [IsStaffOrReadOnly]
    queryset = Product.objects.all()
    def get_queryset(self):
        qs = Product.objects.all()
        if not (self.request.user and self.request.user.is_staff) or self.request.query_params.get("all") != "1":
            qs = qs.filter(is_active=True)
        search = self.request.query_params.get("search", "").strip()
        if search:
            from django.db.models import Q
            qs = qs.filter(Q(name__icontains=search) | Q(sku__icontains=search) | Q(barcode__icontains=search) | Q(category__icontains=search))
        category = self.request.query_params.get("category", "").strip()
        if category:
            qs = qs.filter(category__iexact=category)
        return qs.order_by("name")

class SaleListView(generics.ListAPIView):
    serializer_class = SaleSerializer
    permission_classes = [IsAuthenticated]
    def get_queryset(self):
        qs = Sale.objects.select_related("cashier").prefetch_related("items")
        if not self.request.user.is_staff:
            qs = qs.filter(cashier=self.request.user)
        return qs[:200]

class CheckoutView(APIView):
    permission_classes = [IsAuthenticated]
    def post(self, request):
        payload = CheckoutInputSerializer(data=request.data)
        payload.is_valid(raise_exception=True)
        key_text = request.headers.get("Idempotency-Key", "").strip()
        try:
            idempotency_key = UUID(key_text) if key_text else None
        except (ValueError, AttributeError):
            return Response({"detail": "Idempotency-Key must be a valid UUID."}, status=status.HTTP_400_BAD_REQUEST)
        if idempotency_key:
            existing = Sale.objects.filter(idempotency_key=idempotency_key).first()
            if existing:
                return Response(SaleSerializer(existing).data, status=status.HTTP_200_OK)
        data = payload.validated_data
        try:
            with transaction.atomic():
                items = data["items"]
                product_ids = [item["product_id"] for item in items]
                if len(product_ids) != len(set(product_ids)):
                    return Response({"items": "Each product must appear only once in the cart."}, status=status.HTTP_400_BAD_REQUEST)
                products = {p.id: p for p in Product.objects.select_for_update().filter(id__in=product_ids, is_active=True).order_by("id")}
                missing = sorted(set(product_ids) - set(products))
                if missing:
                    return Response({"detail": f"Products not found or inactive: {missing}"}, status=status.HTTP_400_BAD_REQUEST)
                for item in items:
                    product = products[item["product_id"]]
                    if product.stock_quantity < item["quantity"]:
                        return Response({"detail": f"Insufficient stock for {product.name}. Available: {product.stock_quantity}."}, status=status.HTTP_409_CONFLICT)
                subtotal = Decimal("0.00")
                raw_lines = []
                discount_percent = data["discount_percent"]
                total_discount = Decimal("0.00")
                total_tax = Decimal("0.00")
                total = Decimal("0.00")
                for item in items:
                    product = products[item["product_id"]]
                    qty = item["quantity"]
                    line_subtotal = money(product.price * qty)
                    line_discount = money(line_subtotal * discount_percent / Decimal("100"))
                    taxable = line_subtotal - line_discount
                    line_tax = money(taxable * product.tax_rate / Decimal("100"))
                    line_total = taxable + line_tax
                    subtotal += line_subtotal
                    total_discount += line_discount
                    total_tax += line_tax
                    total += line_total
                    raw_lines.append((product, qty, line_discount, line_tax, line_total))
                subtotal, total_discount, total_tax, total = map(money, (subtotal, total_discount, total_tax, total))
                tendered = data.get("amount_tendered")
                if data["payment_method"] == "cash":
                    if tendered is None:
                        return Response({"amount_tendered": "Cash amount received is required."}, status=status.HTTP_400_BAD_REQUEST)
                    tendered = money(tendered)
                    if tendered < total:
                        return Response({"amount_tendered": f"Amount received must be at least {total}."}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    # Records a payment type only; there is no external payment processor.
                    tendered = total
                sale = Sale.objects.create(
                    cashier=request.user, subtotal=subtotal, discount_amount=total_discount,
                    tax_amount=total_tax, total_amount=total, payment_method=data["payment_method"],
                    amount_tendered=tendered, change_due=money(max(Decimal("0.00"), tendered-total)),
                    idempotency_key=idempotency_key,
                )
                for product, qty, line_discount, line_tax, line_total in raw_lines:
                    SaleItem.objects.create(sale=sale, product=product, product_name=product.name, sku=product.sku,
                        quantity=qty, unit_price=product.price, discount_amount=line_discount, tax_amount=line_tax, line_total=line_total)
                    product.stock_quantity -= qty
                    product.save(update_fields=["stock_quantity", "updated_at"])
                    InventoryMovement.objects.create(product=product, user=request.user, change_quantity=-qty, reason="Sale", reference=sale.receipt_number)
        except IntegrityError:
            if idempotency_key:
                existing = Sale.objects.filter(idempotency_key=idempotency_key).first()
                if existing:
                    return Response(SaleSerializer(existing).data, status=status.HTTP_200_OK)
            raise
        sale = Sale.objects.select_related("cashier").prefetch_related("items").get(pk=sale.pk)
        return Response(SaleSerializer(sale).data, status=status.HTTP_201_CREATED)

class SummaryView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        today = timezone.localdate()
        sales = Sale.objects.filter(created_at__date=today)
        if not request.user.is_staff:
            sales = sales.filter(cashier=request.user)
        stats = sales.aggregate(total=Sum("total_amount"), count=Count("id"))
        products = Product.objects.filter(is_active=True)
        low_stock = products.filter(stock_quantity__lte=F("reorder_level")).count()
        return Response({"date": today.isoformat(), "sales_total": money(stats["total"] or Decimal("0.00")), "sales_count": stats["count"] or 0, "low_stock_count": low_stock, "active_products": products.count()})

class InventoryAdjustmentView(APIView):
    permission_classes = [IsAdminUser]
    def post(self, request):
        serializer = InventoryAdjustmentSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        with transaction.atomic():
            try:
                product = Product.objects.select_for_update().get(pk=data["product_id"], is_active=True)
            except Product.DoesNotExist:
                return Response({"detail": "Product not found or inactive."}, status=status.HTTP_404_NOT_FOUND)
            new_stock = product.stock_quantity + data["change_quantity"]
            if new_stock < 0:
                return Response({"detail": "Stock cannot become negative."}, status=status.HTTP_409_CONFLICT)
            product.stock_quantity = new_stock
            product.save(update_fields=["stock_quantity", "updated_at"])
            InventoryMovement.objects.create(product=product, user=request.user, change_quantity=data["change_quantity"], reason=data["reason"].strip())
        return Response(ProductSerializer(product).data, status=status.HTTP_200_OK)

class StoreSettingsView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        return Response(StoreSettingsSerializer(StoreSettings.get_settings()).data)
    def put(self, request):
        if not request.user.is_staff:
            return Response({"detail": "Only managers can update store settings."}, status=status.HTTP_403_FORBIDDEN)
        obj = StoreSettings.get_settings()
        serializer = StoreSettingsSerializer(obj, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

class PosThemeSettingsView(APIView):
    """
    API endpoint to retrieve and update persistent POS appearance & theme settings.
    GET: Accessible to authenticated staff and cashiers so POS terminals load the latest theme.
    PUT: Restricted to managers and administrators (is_staff). Cashiers are forbidden.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        theme = PosThemeSettings.get_settings()
        return Response(PosThemeSettingsSerializer(theme).data)

    def put(self, request):
        if not request.user.is_staff:
            return Response(
                {"detail": "Permission denied. Only administrators and managers may modify POS appearance settings."},
                status=status.HTTP_403_FORBIDDEN,
            )
        theme = PosThemeSettings.get_settings()
        serializer = PosThemeSettingsSerializer(theme, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save(updated_by=request.user.get_full_name() or request.user.get_username())
        return Response(serializer.data, status=status.HTTP_200_OK)

