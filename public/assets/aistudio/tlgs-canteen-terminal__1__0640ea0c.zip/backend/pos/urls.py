from django.urls import include, path
from rest_framework.routers import DefaultRouter
from .views import (
    ProductViewSet,
    SaleListView,
    CheckoutView,
    SummaryView,
    InventoryAdjustmentView,
    StoreSettingsView,
    CurrentUserView,
    PosThemeSettingsView,
)
router = DefaultRouter()
router.register("products", ProductViewSet, basename="product")
urlpatterns = [
    path("auth/me/", CurrentUserView.as_view(), name="current-user"),
    path("sales/", SaleListView.as_view(), name="sales-list"),
    path("sales/checkout/", CheckoutView.as_view(), name="sales-checkout"),
    path("reports/summary/", SummaryView.as_view(), name="reports-summary"),
    path("inventory/adjust/", InventoryAdjustmentView.as_view(), name="inventory-adjust"),
    path("settings/", StoreSettingsView.as_view(), name="store-settings"),
    path("theme-settings/", PosThemeSettingsView.as_view(), name="theme-settings"),
    path("", include(router.urls)),
]
