from decimal import Decimal
from rest_framework import serializers
from .models import Product, Sale, SaleItem, StoreSettings, InventoryMovement, PosThemeSettings

class ProductSerializer(serializers.ModelSerializer):
    initial_stock = serializers.IntegerField(write_only=True, required=False, min_value=0)
    class Meta:
        model = Product
        fields = ["id", "sku", "barcode", "name", "category", "price", "tax_rate", "stock_quantity", "reorder_level", "is_active", "initial_stock", "created_at", "updated_at"]
        read_only_fields = ["id", "stock_quantity", "created_at", "updated_at"]
    def validate_sku(self, value):
        return value.strip().upper()
    def validate_barcode(self, value):
        return value.strip()
    def validate_price(self, value):
        if value < 0:
            raise serializers.ValidationError("Price cannot be negative.")
        return value
    def validate_tax_rate(self, value):
        if value < 0 or value > 100:
            raise serializers.ValidationError("Tax rate must be between 0 and 100.")
        return value
    def validate_name(self, value):
        value = value.strip()
        if not value:
            raise serializers.ValidationError("Product name is required.")
        return value
    def create(self, validated_data):
        initial_stock = validated_data.pop("initial_stock", 0)
        product = Product.objects.create(stock_quantity=initial_stock, **validated_data)
        request = self.context.get("request")
        if initial_stock and request and request.user.is_authenticated:
            InventoryMovement.objects.create(product=product, user=request.user, change_quantity=initial_stock, reason="Initial stock")
        return product

class SaleItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = SaleItem
        fields = ["id", "product", "product_name", "sku", "quantity", "unit_price", "discount_amount", "tax_amount", "line_total"]

class SaleSerializer(serializers.ModelSerializer):
    items = SaleItemSerializer(many=True, read_only=True)
    cashier_username = serializers.CharField(source="cashier.username", read_only=True)
    class Meta:
        model = Sale
        fields = ["id", "receipt_number", "cashier_username", "subtotal", "discount_amount", "tax_amount", "total_amount", "payment_method", "amount_tendered", "change_due", "created_at", "items"]

class CheckoutItemInputSerializer(serializers.Serializer):
    product_id = serializers.IntegerField(min_value=1)
    quantity = serializers.IntegerField(min_value=1, max_value=10000)

class CheckoutInputSerializer(serializers.Serializer):
    items = CheckoutItemInputSerializer(many=True, allow_empty=False)
    payment_method = serializers.ChoiceField(choices=["cash", "card", "upi", "other"])
    discount_percent = serializers.DecimalField(max_digits=5, decimal_places=2, min_value=Decimal("0"), max_value=Decimal("100"), required=False, default=Decimal("0"))
    amount_tendered = serializers.DecimalField(max_digits=12, decimal_places=2, min_value=Decimal("0"), required=False)

class InventoryAdjustmentSerializer(serializers.Serializer):
    product_id = serializers.IntegerField(min_value=1)
    change_quantity = serializers.IntegerField(min_value=-1000000, max_value=1000000)
    reason = serializers.CharField(max_length=240, trim_whitespace=True)
    def validate(self, attrs):
        if attrs["change_quantity"] == 0:
            raise serializers.ValidationError({"change_quantity": "Quantity change cannot be zero."})
        if not attrs["reason"]:
            raise serializers.ValidationError({"reason": "A reason is required."})
        return attrs

class StoreSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = StoreSettings
        fields = ["store_name", "address", "phone", "tax_number", "receipt_footer", "currency_code", "updated_at"]
        read_only_fields = ["updated_at"]
    def validate_store_name(self, value):
        if not value.strip():
            raise serializers.ValidationError("Store name is required.")
        return value.strip()
    def validate_currency_code(self, value):
        value = value.strip().upper()
        if len(value) != 3 or not value.isalpha():
            raise serializers.ValidationError("Currency code must be a three-letter code.")
        return value

class PosThemeSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = PosThemeSettings
        fields = [
            "pos_background_color",
            "header_background_color",
            "catalogue_background_color",
            "product_card_background_color",
            "order_panel_background_color",
            "sidebar_background_color",
            "primary_button_color",
            "text_color",
            "accent_color",
            "selected_theme",
            "updated_by",
            "updated_at",
        ]
        read_only_fields = ["updated_at"]

    def _validate_hex(self, value, field_name):
        import re
        val = value.strip()
        if not re.match(r"^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$", val):
            raise serializers.ValidationError(f"Invalid HEX colour format for {field_name}: '{val}'. Must be format like #0B1228 or #FFF.")
        return val.upper()

    def validate_pos_background_color(self, value):
        return self._validate_hex(value, "pos_background_color")

    def validate_header_background_color(self, value):
        return self._validate_hex(value, "header_background_color")

    def validate_catalogue_background_color(self, value):
        return self._validate_hex(value, "catalogue_background_color")

    def validate_product_card_background_color(self, value):
        return self._validate_hex(value, "product_card_background_color")

    def validate_order_panel_background_color(self, value):
        return self._validate_hex(value, "order_panel_background_color")

    def validate_sidebar_background_color(self, value):
        return self._validate_hex(value, "sidebar_background_color")

    def validate_primary_button_color(self, value):
        return self._validate_hex(value, "primary_button_color")

    def validate_text_color(self, value):
        return self._validate_hex(value, "text_color")

    def validate_accent_color(self, value):
        return self._validate_hex(value, "accent_color")
